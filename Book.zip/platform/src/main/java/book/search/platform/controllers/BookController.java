package book.search.platform.controllers;

import book.search.platform.dto.BookCreateDTO;
import book.search.platform.model.Book;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class BookController {
    private final JdbcTemplate jdbcTemplate;

    @GetMapping("/")
    public String homePage(Model model) {
        String sql = "select * from book";
        List<Book> books = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Book.class));
        model.addAttribute("books", books);
        return "home";
    }

    @GetMapping("/book/search")
    public String bookSearch(Model model, @RequestParam(required = false) String search) {
        if (search == null)
            return "redirect:/";
        String sql = "select * from book where title ilike '%" + search + "%' or author ilike '%" + search + "%' or description ilike '%" + search + "%'";
        List<Book> books = jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(Book.class));
        model.addAttribute("books", books);
        return "book_search";
    }

    @GetMapping("/book/create")
    public String bookCreatePage() {
        return "book_create";
    }

    @PostMapping("/book/create")
    public String bookCreate(@ModelAttribute BookCreateDTO dto) {
        String sql = "insert into book(title, author, price, description) values(?,?,?,?);";
        jdbcTemplate.update(sql, dto.title(), dto.author(), dto.price(), dto.description());
        return "redirect:/";
    }

    @GetMapping("/book/update/{id}")
    public String bookUpdatePage(@PathVariable String id, Model model) {
        Book book = jdbcTemplate.queryForObject("select * from book where id=?", BeanPropertyRowMapper.newInstance(Book.class), id);
        model.addAttribute("book", book);
        return "book_update";
    }

    @PostMapping("/book/update")
    public String bookUpdate(@ModelAttribute("book") Book book) {
        var sql = "update book set title = ?, author = ?, price = ?, description = ? where id = ?";
        jdbcTemplate.update(sql,
                book.getTitle(),
                book.getAuthor(),
                book.getPrice(),
                book.getDescription(),
                book.getId()
        );
        return "redirect:/";
    }

    @GetMapping("/book/delete/{id}")
    public String bookDelete(@PathVariable String id, Model model) {
        Book book = jdbcTemplate.queryForObject("select * from book where id=?", BeanPropertyRowMapper.newInstance(Book.class), id);
        model.addAttribute("book", book);
        return "book_delete";
    }

    @PostMapping("/book/delete")
    public String bookDelete(@RequestParam("id") int id) {
        jdbcTemplate.update("delete from book where id=?", id);
        return "redirect:/";
    }

}
