package book.search.platform.dto;

public record BookCreateDTO(String title, String author, String description, double price) {
}
