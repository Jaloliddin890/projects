create table book (
    id serial primary key ,
    title varchar not null ,
    author varchar not null ,
    description varchar not null ,
    price float
);
