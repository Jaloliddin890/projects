insert into book (title, author, description, price)
values ('Spring in Action', 'Unknown', 'A book for new learners', '50');
